// Key Management & Licensing System
// Controls customer keys, custom expiration in days, creation of user accounts, and master credentials.

import {
  verifyMasterSecret,
  generateCryptographicKey,
  validateCryptographicKey,
  signSessionPayload,
  verifySessionIntegrity,
} from './cryptoAuth';
import { clearSecurityUnlockCooldown, isSecurityUnlocked, getSecurityRemainingSeconds } from './security';
import {
  getCurrentDeviceInfoSync,
  getPersistentHwid,
  maskIp,
  DeviceInfo,
} from './deviceSecurity';
import {
  syncKeyToCloud,
  syncUserToCloud,
  deleteKeyFromCloud,
  deleteUserFromCloud,
} from './firebaseSync';

export interface LicenseKey {
  key: string;
  daysValid: number;
  createdAt: string; // ISO string
  isRedeemed: boolean;
  redeemedBy?: string; // username
  redeemedAt?: string; // ISO string
  expiresAt?: string; // ISO string
  status: 'active' | 'redeemed' | 'expired';
}

export interface LicensedUser {
  username: string;
  passwordHash: string; // Stored securely
  licenseKey: string;
  createdAt: string;
  expiresAt: string; // Expiration timestamp
  daysValid: number;
  status: 'active' | 'expired' | 'suspended';
  sessionSig?: string; // Cryptographic session tamper check
  registeredIp?: string; // Bound Public IP
  registeredDeviceFingerprint?: string; // Bound HWID Hardware Token
  deviceModel?: string; // Friendly Device Name (e.g. iPhone 15 Safari, Windows PC)
  boundIpSubnet?: string; // Bound IP Subnet for dynamic mobile network stability
  lastLoginIp?: string;
  lastLoginAt?: string;
  isIpBound?: boolean;
}

const KEYS_STORAGE_KEY = 'tm_license_keys_v1';
const USERS_STORAGE_KEY = 'tm_licensed_users_v1';
const SESSION_STORAGE_KEY = 'tm_active_client_session';

// Safe UTF-8 Base64 encoding & decoding
export const encodePassword = (password: string): string => {
  try {
    return btoa(encodeURIComponent(password));
  } catch {
    return btoa(password);
  }
};

export const decodePassword = (passwordHash: string): string => {
  try {
    return decodeURIComponent(atob(passwordHash));
  } catch {
    try {
      return atob(passwordHash);
    } catch {
      return passwordHash;
    }
  }
};

// Initial default keys seed that are always valid on any device
const DEFAULT_INITIAL_KEYS: LicenseKey[] = [
  {
    key: 'TM-HZ2W-K3TC-2026',
    daysValid: 365,
    createdAt: new Date().toISOString(),
    isRedeemed: false,
    status: 'active',
  },
  {
    key: 'TM-V1GA-7777-2026',
    daysValid: 30,
    createdAt: new Date().toISOString(),
    isRedeemed: false,
    status: 'active',
  },
  {
    key: 'TM-LID7-9999-2026',
    daysValid: 365,
    createdAt: new Date().toISOString(),
    isRedeemed: false,
    status: 'active',
  },
  {
    key: 'TM-VIP8-2026-VIP7',
    daysValid: 365,
    createdAt: new Date().toISOString(),
    isRedeemed: false,
    status: 'active',
  },
];

// Initial default user seed
const DEFAULT_INITIAL_USERS: LicensedUser[] = [
  {
    username: 'messin',
    passwordHash: encodePassword('1234'),
    licenseKey: 'TM-HZ2W-K3TC-2026',
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
    daysValid: 365,
    status: 'active',
    sessionSig: signSessionPayload('messin', new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()),
  },
];

/**
 * Universal Key Generator with embedded duration and cryptographic signature
 */
export const generateFormattedKey = (days: number = 30): string => {
  return generateCryptographicKey(days);
};

/**
 * Validates and extracts duration from ANY cryptographic key or standard key
 */
export const parseKeyDuration = (keyInput: string): number => {
  const result = validateCryptographicKey(keyInput);
  if (result.valid && result.days > 0) {
    return result.days;
  }
  return 30;
};

/**
 * Checks if a key string is mathematically and cryptographically valid
 */
export const isKeyGloballyValid = (keyInput: string): boolean => {
  const result = validateCryptographicKey(keyInput);
  return result.valid;
};

// Retrieve all keys from storage
export const getStoredKeys = (): LicenseKey[] => {
  try {
    const raw = localStorage.getItem(KEYS_STORAGE_KEY);
    if (!raw) {
      saveStoredKeys(DEFAULT_INITIAL_KEYS);
      return DEFAULT_INITIAL_KEYS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_INITIAL_KEYS;
  }
};

// Save keys
export const saveStoredKeys = (keys: LicenseKey[]): void => {
  try {
    localStorage.setItem(KEYS_STORAGE_KEY, JSON.stringify(keys));
  } catch {}
};

// Create a new key with custom duration in days (supports fractional days e.g. 1/24 for 1 hour)
export const createNewLicenseKey = (daysValid: number): LicenseKey => {
  const keys = getStoredKeys();
  const safeDays = daysValid > 0 ? daysValid : 1 / 24;
  const newKey: LicenseKey = {
    key: generateFormattedKey(Math.max(1, Math.min(36500, Math.round(daysValid)))),
    daysValid: safeDays,
    createdAt: new Date().toISOString(),
    isRedeemed: false,
    status: 'active',
  };
  keys.unshift(newKey);
  saveStoredKeys(keys);
  syncKeyToCloud(newKey);
  return newKey;
};

// Delete key
export const deleteLicenseKey = (keyString: string): void => {
  const cleanKey = keyString.trim().toUpperCase();
  const keys = getStoredKeys().filter((k) => k.key.trim().toUpperCase() !== cleanKey);
  saveStoredKeys(keys);
  deleteKeyFromCloud(cleanKey);
};

// Retrieve all users
export const getStoredUsers = (): LicensedUser[] => {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) {
      saveStoredUsers(DEFAULT_INITIAL_USERS);
      return DEFAULT_INITIAL_USERS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_INITIAL_USERS;
  }
};

// Save users
export const saveStoredUsers = (users: LicensedUser[]): void => {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch {}
};

// Register customer with Username, Password and Key (Works seamlessly on ANY device!)
export const registerUserWithKey = async (
  username: string,
  password: string,
  keyInput: string
): Promise<{ success: boolean; message: string; user?: LicensedUser }> => {
  const cleanUsername = username.trim().toLowerCase();
  const cleanPassword = password.trim();
  const cleanKey = keyInput.trim().toUpperCase();

  if (!cleanUsername || cleanUsername.length < 3) {
    return { success: false, message: 'O nome de usuário deve ter pelo menos 3 caracteres.' };
  }
  if (!cleanPassword || cleanPassword.length < 4) {
    return { success: false, message: 'A senha deve ter pelo menos 4 caracteres.' };
  }

  // Check if username already exists on this device
  const users = getStoredUsers();
  const userExists = users.some((u) => u.username.toLowerCase() === cleanUsername);
  if (userExists) {
    return { success: false, message: 'Este nome de usuário já está cadastrado neste dispositivo.' };
  }

  // Master password bypass
  if (verifyMasterSecret(cleanKey)) {
    const now = new Date();
    const expiresAtDate = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
    const masterUser: LicensedUser = {
      username: cleanUsername,
      passwordHash: encodePassword(cleanPassword),
      licenseKey: 'MASTER-ACCESS-KEY',
      createdAt: now.toISOString(),
      expiresAt: expiresAtDate.toISOString(),
      daysValid: 365,
      status: 'active',
      sessionSig: signSessionPayload(cleanUsername, expiresAtDate.toISOString()),
    };
    users.unshift(masterUser);
    saveStoredUsers(users);
    await syncUserToCloud(masterUser);
    setActiveClientSession(masterUser);
    return { success: true, message: 'Conta Mestre criada com sucesso!', user: masterUser };
  }

  // Universal Validation: Check local storage OR validate algorithmic key on friend's device
  const keys = getStoredKeys();
  let keyIndex = keys.findIndex((k) => k.key.toUpperCase() === cleanKey);

  // If the key was created on another device and sent to friend, dynamically create and validate it locally!
  if (keyIndex === -1) {
    if (isKeyGloballyValid(cleanKey)) {
      const parsedDays = parseKeyDuration(cleanKey);
      const importedKey: LicenseKey = {
        key: cleanKey,
        daysValid: parsedDays,
        createdAt: new Date().toISOString(),
        isRedeemed: false,
        status: 'active',
      };
      keys.unshift(importedKey);
      saveStoredKeys(keys);
      keyIndex = 0;
    } else {
      return { success: false, message: 'Chave de acesso (Key) inválida ou inexistente.' };
    }
  }

  const keyObj = keys[keyIndex];

  if (keyObj.isRedeemed) {
    return { success: false, message: 'Esta chave de acesso já foi resgatada e utilizada.' };
  }

  // Calculate expiration date
  const now = new Date();
  const expiresAtDate = new Date(now.getTime() + keyObj.daysValid * 24 * 60 * 60 * 1000);

  // Mark key as redeemed
  keyObj.isRedeemed = true;
  keyObj.redeemedBy = cleanUsername;
  keyObj.redeemedAt = now.toISOString();
  keyObj.expiresAt = expiresAtDate.toISOString();
  keyObj.status = 'redeemed';
  keys[keyIndex] = keyObj;
  saveStoredKeys(keys);
  await syncKeyToCloud(keyObj);

  // Capture current client Device Fingerprint and Public IP
  const currentDev = getCurrentDeviceInfoSync();

  // Create user with strict device & IP binding
  const newUser: LicensedUser = {
    username: cleanUsername,
    passwordHash: encodePassword(cleanPassword),
    licenseKey: keyObj.key,
    createdAt: now.toISOString(),
    expiresAt: expiresAtDate.toISOString(),
    daysValid: keyObj.daysValid,
    status: 'active',
    sessionSig: signSessionPayload(cleanUsername, expiresAtDate.toISOString()),
    registeredIp: currentDev.ip,
    registeredDeviceFingerprint: currentDev.fingerprint,
    deviceModel: currentDev.deviceModel,
    boundIpSubnet: currentDev.ipSubnet,
    lastLoginIp: currentDev.ip,
    lastLoginAt: now.toISOString(),
    isIpBound: true,
  };

  users.unshift(newUser);
  saveStoredUsers(users);
  await syncUserToCloud(newUser);

  // Set active session
  setActiveClientSession(newUser);

  return { success: true, message: `Conta criada com sucesso! (${keyObj.daysValid} dias de acesso - Dispositivo & IP vinculados)`, user: newUser };
};

// Login customer with Username and Password (with strict IP & Hardware Anti-Sharing Verification)
export const loginClient = (
  username: string,
  password: string
): {
  success: boolean;
  message: string;
  user?: LicensedUser;
  isExpired?: boolean;
  isDeviceMismatch?: boolean;
} => {
  const cleanUsername = username.trim().toLowerCase();
  const cleanPassword = password.trim();

  const users = getStoredUsers();
  const user = users.find((u) => u.username.toLowerCase() === cleanUsername);

  if (!user) {
    return {
      success: false,
      message: `Usuário "${username}" não cadastrado. Clique em "Cadastre-se" com uma chave para criar sua conta.`,
    };
  }

  const decoded = decodePassword(user.passwordHash);
  const isMatch =
    decoded === cleanPassword ||
    user.passwordHash === cleanPassword ||
    user.passwordHash === encodePassword(cleanPassword) ||
    user.passwordHash === btoa(cleanPassword);

  if (!isMatch) {
    return {
      success: false,
      message: 'Senha incorreta para este usuário.',
    };
  }

  // Check expiration & status
  const now = new Date().getTime();
  const expiresAt = new Date(user.expiresAt).getTime();

  if (now > expiresAt || user.status === 'expired' || user.status === 'suspended') {
    return {
      success: false,
      isExpired: true,
      message: 'Sua assinatura expirou ou foi encerrada pelo administrador! Renove seu plano para continuar acessando.',
      user,
    };
  }

  // ADVANCED DEVICE & IP HARDWARE ANTI-FRAUD VERIFICATION:
  const currentDev = getCurrentDeviceInfoSync();

  // If user does not have an IP/Device bound yet, bind it on first login
  if (!user.registeredDeviceFingerprint && !user.registeredIp) {
    user.registeredIp = currentDev.ip;
    user.registeredDeviceFingerprint = currentDev.fingerprint;
    user.deviceModel = currentDev.deviceModel;
    user.boundIpSubnet = currentDev.ipSubnet;
    user.isIpBound = true;
    user.lastLoginIp = currentDev.ip;
    user.lastLoginAt = new Date().toISOString();
    saveStoredUsers(users);
  } else {
    // Check if the current device matches the registered device HWID or registered IP/subnet
    const isMatchingHwid = user.registeredDeviceFingerprint === currentDev.fingerprint;
    const isMatchingIp = user.registeredIp === currentDev.ip || user.boundIpSubnet === currentDev.ipSubnet;

    // If both device HWID and IP do not match, BLOCK login to prevent account leaking/sharing!
    if (!isMatchingHwid && !isMatchingIp) {
      return {
        success: false,
        isDeviceMismatch: true,
        message: `⚠️ ACESSO BLOQUEADO POR IP / DISPOSITIVO: Esta conta está vinculada exclusivamente ao aparelho cadastrado (${user.deviceModel || 'Aparelho Original'} - IP ${maskIp(user.registeredIp)}). O compartilhamento de login é estritamente proibido contra fraudes.`,
        user,
      };
    }

    // Refresh last login info
    user.lastLoginIp = currentDev.ip;
    user.lastLoginAt = new Date().toISOString();
    saveStoredUsers(users);
    syncUserToCloud(user);
  }

  // Ensure session has signature
  if (!user.sessionSig) {
    user.sessionSig = signSessionPayload(user.username, user.expiresAt);
  }

  setActiveClientSession(user);
  return { success: true, message: 'Login realizado com sucesso!', user };
};

// Reset User Device & IP Binding (Admin action when customer changes phone)
export const resetUserDeviceBinding = (username: string): { success: boolean; message: string } => {
  const cleanUsername = username.trim().toLowerCase();
  const users = getStoredUsers();
  const index = users.findIndex((u) => u.username.toLowerCase() === cleanUsername);

  if (index === -1) {
    return { success: false, message: 'Usuário não encontrado.' };
  }

  users[index].registeredIp = undefined;
  users[index].registeredDeviceFingerprint = undefined;
  users[index].deviceModel = undefined;
  users[index].boundIpSubnet = undefined;
  users[index].isIpBound = false;
  saveStoredUsers(users);
  syncUserToCloud(users[index]);

  return {
    success: true,
    message: `Vínculo de IP/Aparelho do usuário "${username}" foi resetado com sucesso! O próximo dispositivo que fizer login será vinculado.`,
  };
};

// Renew expired user with a new key (Works seamlessly on ANY device!)
export const renewUserWithKey = async (
  username: string,
  keyInput: string
): Promise<{ success: boolean; message: string; user?: LicensedUser }> => {
  const cleanUsername = username.trim().toLowerCase();
  const cleanKey = keyInput.trim().toUpperCase();

  const users = getStoredUsers();
  const userIndex = users.findIndex((u) => u.username.toLowerCase() === cleanUsername);

  if (userIndex === -1) {
    return { success: false, message: 'Usuário não encontrado neste dispositivo. Crie uma nova conta em "Cadastre-se".' };
  }

  const keys = getStoredKeys();
  let keyIndex = keys.findIndex((k) => k.key.toUpperCase() === cleanKey);

  // Dynamic import on friend's device
  if (keyIndex === -1) {
    if (isKeyGloballyValid(cleanKey)) {
      const parsedDays = parseKeyDuration(cleanKey);
      const importedKey: LicenseKey = {
        key: cleanKey,
        daysValid: parsedDays,
        createdAt: new Date().toISOString(),
        isRedeemed: false,
        status: 'active',
      };
      keys.unshift(importedKey);
      saveStoredKeys(keys);
      keyIndex = 0;
    } else {
      return { success: false, message: 'Chave de acesso (Key) inválida ou inexistente.' };
    }
  }

  const keyObj = keys[keyIndex];
  if (keyObj.isRedeemed) {
    return { success: false, message: 'Esta chave de acesso já foi resgatada.' };
  }

  const user = users[userIndex];
  const now = new Date();
  const currentExpiry = new Date(user.expiresAt).getTime();
  const baseTime = currentExpiry > now.getTime() ? currentExpiry : now.getTime();
  const newExpiry = new Date(baseTime + keyObj.daysValid * 24 * 60 * 60 * 1000);

  // Mark key as redeemed
  keyObj.isRedeemed = true;
  keyObj.redeemedBy = cleanUsername;
  keyObj.redeemedAt = now.toISOString();
  keyObj.expiresAt = newExpiry.toISOString();
  keyObj.status = 'redeemed';
  keys[keyIndex] = keyObj;
  saveStoredKeys(keys);
  await syncKeyToCloud(keyObj);

  user.expiresAt = newExpiry.toISOString();
  user.status = 'active';
  user.sessionSig = signSessionPayload(cleanUsername, newExpiry.toISOString());
  users[userIndex] = user;
  saveStoredUsers(users);
  await syncUserToCloud(user);

  setActiveClientSession(user);
  return { success: true, message: `Renovado com sucesso por mais ${keyObj.daysValid} dias!`, user };
};

// Active Session helpers
export const setActiveClientSession = (user: LicensedUser): void => {
  try {
    if (!user.sessionSig) {
      user.sessionSig = signSessionPayload(user.username, user.expiresAt);
    }
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
  } catch {}
};

export const getActiveClientSession = (): LicensedUser | null => {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const user: LicensedUser = JSON.parse(raw);
    
    // Cryptographic anti-tampering check: verify that expiry was not altered manually
    if (user.sessionSig && !verifySessionIntegrity(user.username, user.expiresAt, user.sessionSig)) {
      clearActiveClientSession();
      return null;
    }

    // MANDATORY REAL-TIME CROSS-CHECK AGAINST CENTRAL USER LIST (Synchronized with Firestore)
    const users = getStoredUsers();
    const storedUser = users.find((u) => u.username.toLowerCase() === user.username.toLowerCase());

    if (!storedUser) {
      clearActiveClientSession();
      return null;
    }

    if (
      storedUser.status === 'expired' ||
      storedUser.status === 'suspended' ||
      new Date().getTime() >= new Date(storedUser.expiresAt).getTime()
    ) {
      clearActiveClientSession();
      if (storedUser.status !== 'expired') {
        storedUser.status = 'expired';
        saveStoredUsers(users);
      }
      return null;
    }

    // MANDATORY CROSS-CHECK LINKED KEY STATUS
    if (storedUser.licenseKey) {
      const keys = getStoredKeys();
      const linkedKey = keys.find((k) => k.key.toUpperCase() === storedUser.licenseKey.toUpperCase());
      if (linkedKey && linkedKey.status === 'expired') {
        clearActiveClientSession();
        return null;
      }
    }

    return storedUser;
  } catch {
    clearActiveClientSession();
    return null;
  }
};

export const clearActiveClientSession = (): void => {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    localStorage.removeItem('tm_last_active_view');
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('tm:client_session_cleared'));
    }
  } catch {}
};

/**
 * Validates all active sessions (security cooldown and client user session)
 * Automatically invalidates any expired session and returns overall access authorization.
 */
export const checkAndInvalidateAllSessions = (): {
  hasValidAccess: boolean;
  type?: 'security_cooldown' | 'client_session';
  username?: string;
  remainingSeconds?: number;
} => {
  // 1. Check Owner/Security Passcode Cooldown
  if (isSecurityUnlocked()) {
    return {
      hasValidAccess: true,
      type: 'security_cooldown',
      remainingSeconds: getSecurityRemainingSeconds(),
    };
  }

  // 2. Check Client User Session
  const clientSession = getActiveClientSession();
  if (clientSession) {
    const diff = Math.max(0, Math.floor((new Date(clientSession.expiresAt).getTime() - Date.now()) / 1000));
    return {
      hasValidAccess: true,
      type: 'client_session',
      username: clientSession.username,
      remainingSeconds: diff,
    };
  }

  return {
    hasValidAccess: false,
  };
};


// Calculate remaining days for user (returns 0 if expired or suspended)
export const getRemainingDays = (expiresAtISO: string, status?: string): number => {
  if (status === 'expired' || status === 'suspended') return 0;
  const diff = new Date(expiresAtISO).getTime() - Date.now();
  if (diff <= 0) return 0;
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
};

// Admin update of customer password
export const updateUserPassword = (
  username: string,
  newPassword: string
): { success: boolean; message: string } => {
  const cleanUsername = username.trim().toLowerCase();
  const cleanPassword = newPassword.trim();

  if (!cleanPassword || cleanPassword.length < 4) {
    return { success: false, message: 'A nova senha deve ter pelo menos 4 caracteres.' };
  }

  const users = getStoredUsers();
  const index = users.findIndex((u) => u.username.toLowerCase() === cleanUsername);
  if (index === -1) {
    return { success: false, message: 'Usuário não encontrado.' };
  }

  users[index].passwordHash = encodePassword(cleanPassword);
  saveStoredUsers(users);
  syncUserToCloud(users[index]);

  // If user is currently active session, update their session too
  const currentSession = getActiveClientSession();
  if (currentSession && currentSession.username.toLowerCase() === cleanUsername) {
    currentSession.passwordHash = encodePassword(cleanPassword);
    setActiveClientSession(currentSession);
  }

  return { success: true, message: `Senha do usuário ${username} alterada com sucesso!` };
};

// Delete user account
export const deleteUser = (username: string): void => {
  const cleanUsername = username.trim().toLowerCase();
  const users = getStoredUsers().filter((u) => u.username.toLowerCase() !== cleanUsername);
  saveStoredUsers(users);
  deleteUserFromCloud(cleanUsername);

  // If active session was this user, clear session
  const currentSession = getActiveClientSession();
  if (currentSession && currentSession.username.toLowerCase() === cleanUsername) {
    clearActiveClientSession();
    clearSecurityUnlockCooldown();
  }
};

// Force immediately expire a user's license/account
export const expireUserNow = async (username: string): Promise<{ success: boolean; message: string }> => {
  const cleanUsername = username.trim().toLowerCase();
  const users = getStoredUsers();
  const index = users.findIndex((u) => u.username.toLowerCase() === cleanUsername);

  if (index === -1) {
    return { success: false, message: 'Usuário não encontrado.' };
  }

  // Set past date and expired status
  const pastDate = new Date(Date.now() - 3600000).toISOString();
  users[index].expiresAt = pastDate;
  users[index].status = 'expired';
  users[index].sessionSig = signSessionPayload(cleanUsername, pastDate);
  saveStoredUsers(users);
  await syncUserToCloud(users[index]);

  // Expire key if linked
  const linkedKey = users[index].licenseKey;
  if (linkedKey) {
    const keys = getStoredKeys();
    const kIdx = keys.findIndex((k) => k.key.toUpperCase() === linkedKey.toUpperCase());
    if (kIdx !== -1) {
      keys[kIdx].status = 'expired';
      keys[kIdx].expiresAt = pastDate;
      saveStoredKeys(keys);
      await syncKeyToCloud(keys[kIdx]);
    }
  }

  // Clear active session and security unlock cooldown
  clearActiveClientSession();
  clearSecurityUnlockCooldown();

  return { success: true, message: `O acesso do usuário "${username}" foi EXPIRADO imediatamente!` };
};

// Reactivate or extend a user's license
export const reactivateUser = async (
  username: string,
  daysToAdd: number = 30
): Promise<{ success: boolean; message: string }> => {
  const cleanUsername = username.trim().toLowerCase();
  const users = getStoredUsers();
  const index = users.findIndex((u) => u.username.toLowerCase() === cleanUsername);

  if (index === -1) {
    return { success: false, message: 'Usuário não encontrado.' };
  }

  const now = Date.now();
  const currentExpiry = new Date(users[index].expiresAt).getTime();
  const baseTime = (users[index].status === 'expired' || currentExpiry < now) ? now : currentExpiry;
  const newExpiry = new Date(baseTime + Math.max(1, daysToAdd) * 24 * 60 * 60 * 1000);

  users[index].expiresAt = newExpiry.toISOString();
  users[index].status = 'active';
  users[index].daysValid = Math.max(users[index].daysValid, daysToAdd);
  users[index].sessionSig = signSessionPayload(cleanUsername, newExpiry.toISOString());
  saveStoredUsers(users);
  await syncUserToCloud(users[index]);

  // If user has a linked key, reactivate that key as well
  const linkedKey = users[index].licenseKey;
  if (linkedKey) {
    const keys = getStoredKeys();
    const kIdx = keys.findIndex((k) => k.key.toUpperCase() === linkedKey.toUpperCase());
    if (kIdx !== -1) {
      keys[kIdx].status = 'active';
      keys[kIdx].expiresAt = newExpiry.toISOString();
      keys[kIdx].daysValid = Math.max(keys[kIdx].daysValid, daysToAdd);
      saveStoredKeys(keys);
      await syncKeyToCloud(keys[kIdx]);
    }
  }

  return { success: true, message: `Usuário "${username}" REATIVADO com sucesso por mais ${daysToAdd} dias!` };
};

// Force expire an unused or active key
export const expireKeyNow = async (keyString: string): Promise<{ success: boolean; message: string }> => {
  const cleanKey = keyString.trim().toUpperCase();
  const keys = getStoredKeys();
  const index = keys.findIndex((k) => k.key.toUpperCase() === cleanKey);

  if (index === -1) {
    return { success: false, message: 'Chave não encontrada.' };
  }

  const pastDate = new Date(Date.now() - 3600000).toISOString();
  keys[index].status = 'expired';
  keys[index].isRedeemed = true;
  keys[index].expiresAt = pastDate;
  saveStoredKeys(keys);
  await syncKeyToCloud(keys[index]);

  // If redeemed by a user, expire that user too
  if (keys[index].redeemedBy) {
    await expireUserNow(keys[index].redeemedBy!);
  } else {
    // Check all users with this key
    const users = getStoredUsers();
    let hasUpdated = false;
    for (const u of users) {
      if (u.licenseKey && u.licenseKey.toUpperCase() === cleanKey) {
        u.status = 'expired';
        u.expiresAt = pastDate;
        u.sessionSig = signSessionPayload(u.username, pastDate);
        await syncUserToCloud(u);
        hasUpdated = true;
      }
    }
    if (hasUpdated) {
      saveStoredUsers(users);
    }
  }

  clearSecurityUnlockCooldown();
  return { success: true, message: `Chave ${keyString} expirada com sucesso!` };
};

// Expose developer console shortcut for manual key generation
if (typeof window !== 'undefined') {
  (window as any).gerarkey = (days: number = 30) => {
    const newKey = createNewLicenseKey(days);
    console.log(
      '%c🔑 [KEY GERADA COM SUCESSO]',
      'background: #00ffaa; color: #000; font-weight: bold; font-size: 14px; padding: 4px 8px; border-radius: 4px;'
    );
    console.log(`Chave: %c${newKey.key}`, 'color: #00e5ff; font-weight: bold; font-size: 16px;');
    console.log(`Validade: ${newKey.daysValid} dias`);
    console.log(`Criada em: ${newKey.createdAt}`);
    return newKey.key;
  };
}


