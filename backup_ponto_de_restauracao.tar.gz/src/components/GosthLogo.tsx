import React from 'react';

interface GosthLogoProps {
  className?: string;
  size?: number | string;
  withGlow?: boolean;
}

export const GosthLogo: React.FC<GosthLogoProps> = ({
  className = 'w-10 h-10',
  size,
  withGlow = true,
}) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={size ? { width: size, height: size } : undefined}
    >
      {withGlow && (
        <div className="absolute inset-0 bg-red-600/30 blur-lg rounded-full pointer-events-none" />
      )}
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full relative z-10 drop-shadow-[0_2px_12px_rgba(220,38,38,0.5)]"
      >
        <defs>
          <linearGradient id="gosthRedGradPrimary" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ff2a3b" />
            <stop offset="50%" stopColor="#dc2626" />
            <stop offset="100%" stopColor="#991b1b" />
          </linearGradient>
          <linearGradient id="gosthRedGradDark" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#b91c1c" />
            <stop offset="100%" stopColor="#7f1d1d" />
          </linearGradient>
        </defs>

        {/* Sharp geometric stylized falcon / shield mark matching gosth.gg */}
        {/* Left Wing / Outer Blade */}
        <path
          d="M12 18 L48 18 L26 46 L38 46 L14 82 L32 54 L18 54 Z"
          fill="url(#gosthRedGradPrimary)"
        />

        {/* Right Wing / Inner Shield Angle */}
        <path
          d="M52 18 L88 18 L52 82 L64 46 L40 46 L54 18 Z"
          fill="url(#gosthRedGradDark)"
        />

        {/* Central Dynamic Diamond Accent */}
        <polygon
          points="50,22 72,22 42,78 32,50"
          fill="url(#gosthRedGradPrimary)"
          opacity="0.9"
        />

        {/* Sharp Angle Highlights */}
        <path
          d="M12 18 L48 18 L34 36 L12 18 Z"
          fill="#ff4d5a"
          opacity="0.6"
        />
      </svg>
    </div>
  );
};
