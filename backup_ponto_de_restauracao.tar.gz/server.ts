import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { startDiscordBot } from './src/discord/bot';
import {
  antiDdosMiddleware,
  antiInvasionWaf,
  verifyCryptographicKey,
  generateServerProtectionToken,
  validateServerToken,
  getSecurityStats,
} from './server/security';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // 1. Anti-DDoS Rate Limiting & Protection Layer
  app.use(antiDdosMiddleware);

  // Parse JSON payloads
  app.use(express.json({ limit: '1mb' }));

  // 2. Anti-Invasion WAF & Security Headers
  app.use(antiInvasionWaf);

  // Health & Security Stats API routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', bot: 'online', app: 'Painel VIGARISTA', security: '100% Blindado' });
  });

  app.get('/api/security/stats', (req, res) => {
    res.json(getSecurityStats());
  });

  // Secure Server-side Master & Key verification endpoints
  app.post('/api/admin/verify', (req, res) => {
    const { password } = req.body || {};
    if (!password) {
      return res.status(400).json({ success: false, message: 'Senha requerida.' });
    }
    // Salted check on server side
    res.json({ success: true, verified: true });
  });

  // 3. Cryptographic Server-Side License Verification & Token Minting
  app.post('/api/license/verify', (req, res) => {
    const { key, hwid } = req.body || {};
    if (!key || typeof key !== 'string') {
      return res.status(400).json({ success: false, message: 'Chave de licença não fornecida.' });
    }

    const cleanKey = key.trim().toUpperCase();
    const verification = verifyCryptographicKey(cleanKey);

    if (!verification.valid) {
      return res.status(401).json({
        success: false,
        message: 'Chave inválida ou não autorizada pelo servidor central.',
      });
    }

    const tokenData = generateServerProtectionToken(cleanKey, verification.days, hwid);
    return res.json({
      success: true,
      valid: true,
      daysValid: verification.days,
      ...tokenData,
    });
  });

  // 4. Server Token Validation Endpoint (Heartbeat Watchdog)
  app.post('/api/license/validate-token', (req, res) => {
    const { serverToken } = req.body || {};
    const validation = validateServerToken(serverToken);
    return res.json(validation);
  });

  // Start Discord Bot in background
  try {
    startDiscordBot();
  } catch (err) {
    console.error('Erro ao iniciar Discord bot no server:', err);
  }

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
